#include "pch.h"
#include "CPP_expansions.h"
#include <chrono>

// File 20
// DLL internal state variables
std::chrono::nanoseconds totalPlayTime;

Timer* createTimer()
{
	return new Timer( totalPlayTime );
}

double getPlayTime()
{
	return std::chrono::duration<double>(totalPlayTime).count();
}

void deleteTimer(Timer* instance)
{
	delete instance;
}
