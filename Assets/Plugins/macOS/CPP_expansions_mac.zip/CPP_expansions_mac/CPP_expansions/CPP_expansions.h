#pragma once
#include <chrono>

#ifdef CPP_EXPANSIONS_EXPORTS
#define CPP_EXPANSIONS_API __declspec(dllexport)
#else
#define CPP_EXPANSIONS_API __attribute__((visibility("default"))) // macOS/Linux equivalent
#endif

class Timer
{
public:
	Timer(std::chrono::nanoseconds& result) : result( result ), start( std::chrono::high_resolution_clock::now() ) {};

	~Timer()
	{
		result = std::chrono::high_resolution_clock::now() - start;
	}

private:
	std::chrono::nanoseconds& result;
	const std::chrono::time_point<std::chrono::high_resolution_clock> start;
};

extern "C" CPP_EXPANSIONS_API Timer* createTimer();
extern "C" CPP_EXPANSIONS_API void deleteTimer(Timer* instance);
extern "C" CPP_EXPANSIONS_API double getPlayTime();
